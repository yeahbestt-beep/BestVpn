# Best VPN Android v1.0

Kotlin + Jetpack Compose Android proje kaynakları.

İçerik:
- Best VPN ana ekranı
- Sunucu ekleme/düzenleme/silme
- VLESS / VMess / Trojan / Shadowsocks / SSH modelleri
- Cihazda sunucu saklama
- Android VpnService başlangıç altyapısı
- VPN izin akışı
- APK için Gradle proje yapısı

Kullanım:
1. Klasörü Android Studio ile aç.
2. Gradle Sync yap.
3. Build > Build APK(s).

Önemli:
Bu sürüm gerçek VLESS/VMess/Trojan/Shadowsocks/SSH trafik motorunu içermez.
VpnService tünel giriş noktası ve uygulama arayüzü hazırdır.
QR kamera entegrasyonu sonraki sürümde CameraX/ML Kit ile eklenebilir.
