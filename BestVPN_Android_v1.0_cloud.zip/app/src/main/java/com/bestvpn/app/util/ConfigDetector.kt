package com.bestvpn.app.util
import com.bestvpn.app.model.VpnProtocol

object ConfigDetector {
    fun detect(value: String): VpnProtocol? = when {
        value.trim().lowercase().startsWith("vless://") -> VpnProtocol.VLESS
        value.trim().lowercase().startsWith("vmess://") -> VpnProtocol.VMESS
        value.trim().lowercase().startsWith("trojan://") -> VpnProtocol.TROJAN
        value.trim().lowercase().startsWith("ss://") -> VpnProtocol.SHADOWSOCKS
        value.trim().lowercase().startsWith("ssh://") -> VpnProtocol.SSH
        else -> null
    }
    fun suggestedName(value: String, protocol: VpnProtocol): String =
        "${protocol.title} • QR Sunucu"
}
