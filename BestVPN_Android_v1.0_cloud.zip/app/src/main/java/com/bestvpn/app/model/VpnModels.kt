package com.bestvpn.app.model
import java.util.UUID

enum class VpnProtocol(val title: String) {
    VLESS("VLESS"), VMESS("VMess"), TROJAN("Trojan"), SHADOWSOCKS("Shadowsocks"), SSH("SSH")
}
data class VpnServer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: VpnProtocol,
    val address: String,
    val note: String = ""
)
