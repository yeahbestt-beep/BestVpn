package com.bestvpn.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.bestvpn.app.data.ServerStore
import com.bestvpn.app.model.*
import com.bestvpn.app.vpn.BestVpnService

private val BG = Color(0xFF05070B)
private val CARD = Color(0xFF101722)
private val BLUE = Color(0xFF2F80FF)
private val CYAN = Color(0xFF31D8FF)

@Composable
fun BestVpnApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { ServerStore(context) }
    var servers by remember { mutableStateOf(store.getAll()) }
    var tab by remember { mutableIntStateOf(0) }
    var connected by remember { mutableStateOf(false) }
    var form by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<VpnServer?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = CARD, primary = BLUE, secondary = CYAN)) {
        if (form) {
            ServerForm(editing, onClose = { form = false }, onSave = { s ->
                servers = if (editing == null) servers + s else servers.map { if (it.id == s.id) s else it }
                store.saveAll(servers); form = false
            })
        } else {
            Scaffold(
                containerColor = BG,
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF0A0D12)) {
                        NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Ana Sayfa") })
                        NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Public, null) }, label = { Text("Sunucular") })
                        NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Ayarlar") })
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (tab) {
                        0 -> Home(servers.firstOrNull(), connected) {
                            val prepare = VpnService.prepare(context)
                            if (!connected && prepare != null && context is Activity) context.startActivityForResult(prepare, 1001)
                            else {
                                val i = Intent(context, BestVpnService::class.java)
                                if (connected) i.action = BestVpnService.ACTION_STOP
                                context.startService(i); connected = !connected
                            }
                        }
                        1 -> Servers(servers, { editing = null; form = true }, { editing = it; form = true }, {
                            servers = servers.filterNot { s -> s.id == it.id }; store.saveAll(servers)
                        })
                        else -> Settings()
                    }
                }
            }
        }
    }
}

@Composable
fun Home(server: VpnServer?, connected: Boolean, toggle: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BG, Color(0xFF08152C))))) {
        Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, null, tint = CYAN); Spacer(Modifier.width(8.dp)); Text("Best VPN", style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.weight(1f))
            Button(toggle, Modifier.size(210.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = BLUE)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(if (connected) Icons.Default.Shield else Icons.Default.PowerSettingsNew, null, Modifier.size(48.dp))
                    Text(if (connected) "BAĞLI" else "BAĞLAN")
                }
            }
            Spacer(Modifier.height(28.dp))
            if (server != null) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CARD)) {
                    Column(Modifier.padding(18.dp)) { Text(server.name); Text(server.protocol.title, color = CYAN) }
                }
            } else Text("Önce bir sunucu ekle.", color = Color.Gray)
            Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun Servers(list: List<VpnServer>, add: () -> Unit, edit: (VpnServer) -> Unit, delete: (VpnServer) -> Unit) {
    Scaffold(containerColor = BG, floatingActionButton = { FloatingActionButton(add) { Icon(Icons.Default.Add, null) } }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Sunucular", style = MaterialTheme.typography.headlineMedium) }
            items(list, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = CARD)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Public, null, tint = CYAN); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(s.name); Text(s.protocol.title, color = BLUE) }
                        IconButton({ edit(s) }) { Icon(Icons.Default.Edit, null) }
                        IconButton({ delete(s) }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
}

@Composable
fun ServerForm(existing: VpnServer?, onClose: () -> Unit, onSave: (VpnServer) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var protocol by remember { mutableStateOf(existing?.protocol ?: VpnProtocol.VLESS) }

    Scaffold(containerColor = BG, topBar = { TopAppBar(
        title = { Text(if (existing == null) "Sunucu Ekle" else "Düzenle") },
        navigationIcon = { TextButton(onClick = onClose) { Text("Geri") } },
        actions = { IconButton(onClick = {}) { Icon(Icons.Default.QrCodeScanner, null) } }
    ) }) { pad ->
        Column(Modifier.padding(pad).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Protokol")
            LazyColumn { items(VpnProtocol.values().toList()) { p ->
                FilterChip(selected = protocol == p, onClick = { protocol = p }, label = { Text(p.title) })
            } }
            OutlinedTextField(name, { name = it }, label = { Text("Sunucu adı") }, Modifier.fillMaxWidth())
            OutlinedTextField(address, { address = it }, label = { Text("Config / URI") }, Modifier.fillMaxWidth().height(160.dp))
            OutlinedTextField(note, { note = it }, label = { Text("Not") }, Modifier.fillMaxWidth())
            Button({ if (name.isNotBlank() && address.isNotBlank()) onSave(VpnServer(existing?.id ?: java.util.UUID.randomUUID().toString(), name, protocol, address, note)) }, Modifier.fillMaxWidth()) { Text("Kaydet") }
        }
    }
}

@Composable
fun Settings() {
    Column(Modifier.fillMaxSize().background(BG).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Ayarlar", style = MaterialTheme.typography.headlineMedium)
        Card(colors = CardDefaults.cardColors(containerColor = CARD)) {
            Column(Modifier.padding(18.dp)) {
                Text("Best VPN"); Text("Android v1.0", color = CYAN)
                Text("VpnService altyapısı hazır. Gerçek protokol taşıma motoru sonraki aşamadır.", color = Color.Gray)
            }
        }
    }
}
