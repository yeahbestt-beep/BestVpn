package com.bestvpn.app.data
import android.content.Context
import com.bestvpn.app.model.*
import org.json.JSONArray
import org.json.JSONObject

class ServerStore(context: Context) {
    private val prefs = context.getSharedPreferences("bestvpn", Context.MODE_PRIVATE)
    fun getAll(): List<VpnServer> {
        val a = JSONArray(prefs.getString("servers", "[]"))
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(VpnServer(o.getString("id"), o.getString("name"),
                    VpnProtocol.valueOf(o.getString("protocol")),
                    o.getString("address"), o.optString("note")))
            }
        }
    }
    fun saveAll(list: List<VpnServer>) {
        val a = JSONArray()
        list.forEach { s -> a.put(JSONObject().apply {
            put("id", s.id); put("name", s.name); put("protocol", s.protocol.name)
            put("address", s.address); put("note", s.note)
        }) }
        prefs.edit().putString("servers", a.toString()).apply()
    }
}
