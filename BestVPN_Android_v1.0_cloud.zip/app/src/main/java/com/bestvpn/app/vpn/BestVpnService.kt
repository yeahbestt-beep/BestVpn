package com.bestvpn.app.vpn
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class BestVpnService : VpnService() {
    private var tunnel: ParcelFileDescriptor? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopTunnel(); stopSelf() }
        else startTunnel()
        return START_STICKY
    }
    private fun startTunnel() {
        if (tunnel != null) return
        tunnel = Builder().setSession("Best VPN")
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .establish()
    }
    private fun stopTunnel() { tunnel?.close(); tunnel = null }
    override fun onDestroy() { stopTunnel(); super.onDestroy() }
    companion object { const val ACTION_STOP = "com.bestvpn.app.STOP_VPN" }
}
